A022F Touch Wake Fix - Power Button v2

This version triggers the TSP fix from the physical Power key.

Behavior:
- If Power is pressed while the display is awake and the phone goes to sleep,
  no TSP command is issued.
- If Power is pressed to wake the phone and Android reaches Awake state,
  it runs:

    echo check_connection > /sys/class/sec/tsp/cmd

The module requires root/Magisk and the Samsung TSP sysfs interface.
It is tailored to the SM-A022F behavior observed during testing.
