#!/system/bin/sh

CMD="/sys/class/sec/tsp/cmd"
RES="/sys/class/sec/tsp/cmd_result"

[ -e "$CMD" ] || exit 0

# Wait for Android to finish booting.
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

# Find the input event node that owns KEY_POWER.
POWER_EVENT=""

for dev in /sys/class/input/event*/device; do
    [ -e "$dev/name" ] || continue

    name="$(cat "$dev/name" 2>/dev/null)"

    case "$name" in
        *kpd*|*keypad*|*KEY_POWER*)
            event="${dev%/device}"
            POWER_EVENT="/dev/input/${event##*/}"
            break
            ;;
    esac
done

# Fallback for the A022F layout observed during testing.
[ -e "$POWER_EVENT" ] || [ -e /dev/input/event2 ] || exit 0
[ -e "$POWER_EVENT" ] || POWER_EVENT="/dev/input/event2"

# Monitor only the Power key release event.
# When the key wakes the phone, wait briefly for Android to enter Awake,
# then ask the Samsung TSP driver to check/reinitialize the connection.
while true; do
    getevent -lt "$POWER_EVENT" 2>/dev/null | while read -r line; do
        case "$line" in
            *EV_KEY*KEY_POWER*UP*|*EV_KEY*003a*UP*)
                sleep 0.25

                state=""
                i=0
                while [ "$i" -lt 20 ]; do
                    state="$(dumpsys power 2>/dev/null | sed -n 's/.*mWakefulness=\([^, ]*\).*/\1/p' | head -n 1)"
                    [ "$state" = "Awake" ] && break
                    sleep 0.1
                    i=$((i + 1))
                done

                if [ "$state" = "Awake" ]; then
                    echo check_connection > "$CMD"
                    sleep 0.2
                    [ -e "$RES" ] && cat "$RES" >/dev/null
                fi
                ;;
        esac
    done

    sleep 1
done
